# Daily
Día 1: Configuración
Día 2: EJS
Día 3: CRUD
