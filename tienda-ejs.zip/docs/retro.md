# Retrospectiva - Estrella de Mar
## Mantener
Buena comunicación
## Empezar
Mejor planificación
## Parar
Trabajar sin dividir tareas
## Más de
Uso de GitHub
## Menos de
Errores sin pruebas
